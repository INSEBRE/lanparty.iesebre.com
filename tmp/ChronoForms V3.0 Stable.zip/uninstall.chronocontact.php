<?php

/*
/**
* CHRONOFORMS version 3.0 stable
* Copyright (c) 2006 Chrono_Man, ChronoEngine.com. All rights reserved.
* Author: Chrono_Man (ChronoEngine.com)
* See readme.html.
* Visit http://www.ChronoEngine.com for regular update and information.
**/

function com_uninstall() {
 echo "Thank you for using this component. The component has been uninstalled. If you have questions or comments, please contact webmaster@chronoengine.com";
}
?>
